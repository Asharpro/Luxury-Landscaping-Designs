# Luxury Landscape Designs - Standalone HTML5, CSS3 & JavaScript Website

A modern, responsive, high-performance static website for **Luxury Landscape Designs**. Built purely with HTML5, CSS3, and vanilla JavaScript—completely independent of WordPress or PHP.

---

## 📁 Project Structure

`
luxury-landscape-html/
├── index.html              # Home Page
├── about.html              # About Us Page
├── services.html           # Services Page (All 9 Core Services)
├── projects.html           # Portfolio / Projects Page with Category Filter & Lightbox
├── contact.html            # Contact & Free Consultation Page
├── css/
│   └── style.css           # Production CSS3 Stylesheet (Variables, Animations, Responsive)
├── js/
│   └── main.js             # Interactive JavaScript (Sticky header, Mobile menu, Counters, Filter, Form)
├── images/                 # All 47 high-res images, user logos, and favicons
└── server.py               # Lightweight local development server
`

---

## 🚀 How to Run Locally

### Option 1: Direct File Opening
Simply double-click index.html to open the website directly in any web browser (Chrome, Edge, Firefox, Safari).

### Option 2: Python Local Server
Run:
`ash
python server.py
`
Then visit [http://localhost:8000](http://localhost:8000) in your browser.

---

## 🌐 How to Deploy to Static Hosting

This website has zero backend dependencies and can be deployed directly to:
- **Netlify**: Drag & drop this folder into your Netlify dashboard.
- **Vercel**: Run ercel or connect your repository.
- **GitHub Pages**: Push this directory to a repository and enable GitHub Pages on the main branch.
- **cPanel / Apache / Nginx**: Upload all files to your public_html or web root directory.

---

## 📞 Business Details
- **Business**: Luxury Landscape Designs
- **Phone**: (206) 945-9777
- **Email**: luxurylandscape16@gmail.com
- **Region**: Serving Puget Sound & Surrounding Areas
