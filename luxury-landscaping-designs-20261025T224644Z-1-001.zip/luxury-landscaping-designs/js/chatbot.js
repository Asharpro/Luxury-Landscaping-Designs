/**
 * Luxury Landscape Designs - Interactive AI Chatbot Widget
 * 
 * Provides automated architectural hardscape guidance, pricing estimates,
 * service details, PNW climate/drainage answers, and instant consultation booking.
 */

(function () {
  'use strict';

  // Chatbot Knowledge Base & Intent Matching
  var BOT_KNOWLEDGE = [
    {
      keywords: ['hello', 'hi', 'hey', 'start', 'help', 'good morning', 'good afternoon'],
      response: `
        <p>Hello! Welcome to <strong>Luxury Landscape Designs</strong>. I'm your digital landscape concierge.</p>
        <p>How can I help you today? You can ask about:</p>
        <ul>
          <li>💰 <strong>Pricing & Budget Tiers</strong></li>
          <li>🧱 <strong>Pavers vs. Poured Concrete</strong></li>
          <li>🛠️ <strong>Our 8 Core Services</strong></li>
          <li>🌧️ <strong>PNW Drainage & Retaining Walls</strong></li>
          <li>📅 <strong>Booking a Free On-Site Consultation</strong></li>
        </ul>
      `,
      chips: ['Estimate Project Cost', 'Pavers vs Concrete', 'Core Services', 'Book Consultation']
    },
    {
      keywords: ['cost', 'price', 'pricing', 'estimate', 'budget', 'quote', 'rate', 'how much'],
      response: `
        <p>We provide 100% transparent, <strong>guaranteed fixed-price quotes</strong> with zero hidden fees. Here are our typical project tiers:</p>
        <ul>
          <li><strong>The Architectural Accent ($15k – $30k):</strong> 350–600 sq.ft. paver or stone patio, walkway & garden edging.</li>
          <li><strong>The Modern Oasis ($35k – $75k):</strong> Multi-level bluestone/paver terrace, custom cedar deck, gas fire pit & LED lighting.</li>
          <li><strong>The Estate Sanctuary ($80k – $150k+):</strong> Resort-style outdoor living, outdoor kitchen, structural retaining walls & automated irrigation.</li>
        </ul>
        <p>Would you like a complimentary on-site measurement? Call us at <a href="tel:2069459777"><strong>(206) 945-9777</strong></a> or visit our <a href="contact.html">Consultation Page</a>.</p>
      `,
      chips: ['Book Free Consultation', 'Pavers vs Concrete', 'Warranty Coverage', 'Call Direct']
    },
    {
      keywords: ['paver', 'concrete', 'pavers vs concrete', 'crack', 'driveway', 'poured concrete'],
      response: `
        <p>In the Pacific Northwest, <strong>interlocking pavers are vastly superior to poured concrete</strong> for three reasons:</p>
        <ul>
          <li><strong>8,000+ PSI Compressive Strength:</strong> Pavers are more than double the strength of standard poured concrete (3,500 PSI).</li>
          <li><strong>Freeze-Thaw Flexibility:</strong> Interlocking joints flex naturally with winter moisture without unsightly structural cracking.</li>
          <li><strong>Lifetime Serviceability:</strong> If underground utilities ever need repair, pavers can be unzipped and seamlessly reset with zero scars.</li>
        </ul>
        <p>We install Belgard, Unilock, and Pennsylvania Bluestone with high-polymer locking sand.</p>
      `,
      chips: ['Our 8 Core Services', 'Estimate Project Cost', 'Book Consultation']
    },
    {
      keywords: ['drainage', 'rain', 'water', 'runoff', 'mud', 'slope', 'retaining wall', 'french drain', 'standing water'],
      response: `
        <p>Puget Sound receives 38+ inches of annual rainfall, making <strong>subsurface civil drainage engineering</strong> essential:</p>
        <ul>
          <li><strong>Laser Elevation Gradients:</strong> Minimum 1.5% to 2% pitch away from home foundations.</li>
          <li><strong>Subsurface French Drains:</strong> Perforated pipe wrapped in non-woven geotextile and washed basalt rock.</li>
          <li><strong>Structural Basalt Retaining Walls:</strong> Hydrostatic weep holes and crushed rock backfill to prevent soil slope collapse.</li>
        </ul>
        <p>Our drainage solutions permanently protect your home foundation and lawn from puddles and erosion.</p>
      `,
      chips: ['Book Free Consultation', 'Estimate Project Cost', 'Service Areas']
    },
    {
      keywords: ['services', 'what do you do', 'service', 'offer', 'patio', 'deck', 'fence', 'irrigation', 'walkway', 'steps', 'garden'],
      response: `
        <p>We specialize in <strong>8 master-level design-build disciplines</strong>:</p>
        <ol>
          <li><strong>Brick & Stone Patios:</strong> Pennsylvania Bluestone, flagstone & granite terraces.</li>
          <li><strong>Walks & Steps:</strong> Welcoming front walkways and hillside stone steps.</li>
          <li><strong>Garden Installation:</strong> Native PNW drought-tolerant botanical landscaping.</li>
          <li><strong>Interlocking Pavers:</strong> Permeable driveways and outdoor living plazas.</li>
          <li><strong>Irrigation Systems:</strong> Smart WiFi-controlled drip and micro-spray lines.</li>
          <li><strong>Wood Fences:</strong> Architectural clear Western Red Cedar privacy fencing.</li>
          <li><strong>Custom Decks:</strong> Multi-tier kiln-dried cedar and composite decking.</li>
          <li><strong>Concrete Driveways:</strong> Steel-reinforced 4,000 PSI stamped & exposed aggregate.</li>
        </ol>
        <p>Check out our full <a href="services.html">Services Catalog</a> for photos and details.</p>
      `,
      chips: ['View Portfolio', 'Estimate Project Cost', 'Book Free Consultation']
    },
    {
      keywords: ['material', 'materials', 'bluestone', 'cedar', 'stone', 'wood', 'granite', 'basalt'],
      response: `
        <p>We source only <strong>premier, sustainable, architectural-grade materials</strong>:</p>
        <ul>
          <li><strong>Pennsylvania Bluestone:</strong> Thermal cleft finish, naturally non-slip and timeless.</li>
          <li><strong>Belgard Interlocking Pavers:</strong> 8,000+ PSI with fade-resistant mineral pigments.</li>
          <li><strong>Old-Growth Western Red Cedar:</strong> Kiln-dried, naturally rot-resistant Pacific Northwest timber.</li>
          <li><strong>Rebar-Reinforced Concrete:</strong> 4,000 PSI with Grade-60 steel grid reinforcement.</li>
        </ul>
        <p>Visit our <a href="services.html">Materials Matrix</a> to compare PSI ratings and lifespans.</p>
      `,
      chips: ['Estimate Project Cost', 'Pavers vs Concrete', 'Book Consultation']
    },
    {
      keywords: ['area', 'areas', 'location', 'locations', 'where', 'seattle', 'bellevue', 'kirkland', 'redmond', 'mercer island', 'city', 'cities'],
      response: `
        <p>We proudly serve homeowners across the <strong>Greater Seattle & Puget Sound basin</strong>, including:</p>
        <ul>
          <li><strong>King County:</strong> Seattle, Bellevue, Kirkland, Redmond, Mercer Island, Medina, Sammamish, Issaquah, Woodinville, Renton.</li>
          <li><strong>Pierce County:</strong> Tacoma, Puyallup, Gig Harbor, University Place, Lakewood.</li>
          <li><strong>Snohomish County:</strong> Edmonds, Lynnwood, Bothell, Mill Creek.</li>
        </ul>
        <p>Live nearby? Call <a href="tel:2069459777"><strong>(206) 945-9777</strong></a> to confirm your address!</p>
      `,
      chips: ['Book Free Consultation', 'Estimate Project Cost', 'Call Direct']
    },
    {
      keywords: ['warranty', 'guarantee', 'insured', 'license', 'licensed', 'bonded'],
      response: `
        <p>You are fully protected with <strong>The Luxury Standard Guarantee</strong>:</p>
        <ul>
          <li>🛡️ <strong>5-Year Structural Craftsmanship Warranty:</strong> Backs all paver settling, masonry mortar joints, retaining walls, and deck joinery in writing.</li>
          <li>📜 <strong>WA Contractor License #LUXURLD821K9:</strong> Fully licensed, bonded, and backed by $2,000,000 commercial liability insurance.</li>
          <li>🏅 <strong>Certified Master Builders:</strong> ICPI (Interlocking Concrete Pavement Institute) and NCMA certified.</li>
          <li>💎 <strong>Manufacturer Coverage:</strong> Up to 25 years or lifetime warranties on Belgard pavers and composite decking.</li>
        </ul>
      `,
      chips: ['Book Free Consultation', 'Core Services', 'Call Direct']
    },
    {
      keywords: ['book', 'consult', 'consultation', 'appointment', 'schedule', 'contact', 'call', 'phone', 'email', 'talk to someone'],
      response: `
        <p>Scheduling a <strong>Complimentary On-Site Design Consultation</strong> is quick and easy:</p>
        <p>Our lead estimator visits your home, conducts laser topographical elevation measurements, reviews material swatches, and provides a <strong>free 3D CAD rendering & fixed-price proposal</strong>.</p>
        <p>👉 Call us now: <a href="tel:2069459777"><strong>(206) 945-9777</strong></a><br>
        📧 Email: <a href="mailto:luxurylandscape16@gmail.com"><strong>luxurylandscape16@gmail.com</strong></a><br>
        📝 Or submit details on our <a href="contact.html"><strong>Contact & Estimate Page</strong></a>.</p>
      `,
      chips: ['Call Direct: (206) 945-9777', 'Estimate Project Cost', 'Our 8 Core Services']
    },
    {
      keywords: ['project', 'projects', 'portfolio', 'work', 'photos', 'gallery', 'case study', 'bellevue hillside', 'mercer island'],
      response: `
        <p>We've completed over <strong>450+ estate transformations</strong> in Washington! Recent featured projects include:</p>
        <ul>
          <li><strong>Bellevue Hillside Sanctuary:</strong> 1,400 sq.ft. multi-level Pennsylvania Bluestone patio with gas fire pit.</li>
          <li><strong>Mercer Island Culinary Terrace:</strong> 950 sq.ft. architectural clear cedar deck with granite outdoor kitchen island.</li>
          <li><strong>Kirkland Motor Court:</strong> 2,200 sq.ft. permeable interlocking paver driveway with zero standing water.</li>
        </ul>
        <p>View high-res photos in our <a href="projects.html">Portfolio Gallery</a>.</p>
      `,
      chips: ['Book Free Consultation', 'Estimate Project Cost', 'Pavers vs Concrete']
    }
  ];

  // Default fallback response
  var DEFAULT_RESPONSE = `
    <p>Thank you for your question! As your luxury outdoor living specialist, I want to make sure you get exact specifications for your property.</p>
    <p>You can speak directly with our lead estimator right now at <a href="tel:2069459777"><strong>(206) 945-9777</strong></a>, or submit your site details on our <a href="contact.html"><strong>Contact Form</strong></a>.</p>
    <p>Or choose a popular topic below:</p>
  `;
  var DEFAULT_CHIPS = ['Estimate Project Cost', 'Pavers vs Concrete', 'Our 8 Core Services', 'Book Consultation'];

  // DOM Elements Injection
  function injectChatbotDOM() {
    if (document.getElementById('luxury-chat-widget')) return;

    var container = document.createElement('div');
    container.id = 'luxury-chat-widget';
    container.innerHTML = `
      <!-- Teaser Bubble -->
      <div class="luxury-chat-teaser" id="luxuryChatTeaser" role="alert">
        <span>👋 Need a landscape or patio quote? Ask our specialist!</span>
        <button type="button" class="teaser-close-btn" id="luxuryTeaserClose" aria-label="Close message">&times;</button>
      </div>

      <!-- Floating Trigger Button -->
      <button type="button" class="luxury-chat-trigger" id="luxuryChatTrigger" aria-label="Open Luxury Landscape AI Assistant" aria-expanded="false">
        <div class="luxury-chat-pulse"></div>
        <span class="luxury-chat-badge" id="luxuryChatBadge">1</span>
        
        <!-- Chat Bubble Icon -->
        <svg class="luxury-chat-icon" viewBox="0 0 24 24">
          <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
        </svg>
        
        <!-- Close (X) Icon -->
        <svg class="luxury-chat-close-icon" viewBox="0 0 24 24">
          <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
        </svg>
      </button>

      <!-- Chat Window Modal -->
      <div class="luxury-chat-window" id="luxuryChatWindow" role="dialog" aria-modal="true" aria-label="Luxury Landscape Virtual Assistant">
        <!-- Header -->
        <div class="luxury-chat-header">
          <div class="chat-brand-meta">
            <div class="chat-avatar-wrap">
              🌿
              <span class="chat-online-indicator" title="Online"></span>
            </div>
            <div class="chat-title-box">
              <h3>Luxury Landscape Concierge</h3>
              <span class="chat-status-text">
                <span style="font-size: 8px;">●</span> Online | Instant Answers
              </span>
            </div>
          </div>
          <div class="chat-header-actions">
            <button type="button" class="chat-action-btn" id="luxuryChatReset" title="Restart Conversation" aria-label="Restart Conversation">
              ↺
            </button>
            <button type="button" class="chat-action-btn" id="luxuryChatClose" title="Close Chat" aria-label="Close Chat">
              ✕
            </button>
          </div>
        </div>

        <!-- Messages Body -->
        <div class="luxury-chat-body" id="luxuryChatBody">
          <span class="chat-timestamp-badge">Today • Luxury Landscape Assistant</span>
          
          <!-- Initial Welcome Message -->
          <div class="chat-msg bot">
            <div class="msg-avatar">🌿</div>
            <div class="msg-content">
              <p>Hello! Welcome to <strong>Luxury Landscape Designs</strong>. I'm your digital outdoor living specialist.</p>
              <p>How can I assist your landscaping project today?</p>
              <div class="chat-suggestions-wrap" id="chatInitialSuggestions">
                <button type="button" class="chat-chip" data-query="Estimate Project Cost">💰 Estimate Project Cost</button>
                <button type="button" class="chat-chip" data-query="Pavers vs Concrete">🧱 Pavers vs Concrete</button>
                <button type="button" class="chat-chip" data-query="Our 8 Core Services">🛠️ Core Services</button>
                <button type="button" class="chat-chip" data-query="Drainage & Retaining Walls">🌧️ Drainage Solutions</button>
                <button type="button" class="chat-chip" data-query="Book Free Consultation">📅 Book Free Consultation</button>
                <button type="button" class="chat-chip" data-query="Call Direct">📞 (206) 945-9777</button>
              </div>
              <span class="msg-time">Just now</span>
            </div>
          </div>

          <!-- Typing Indicator (hidden by default) -->
          <div class="chat-msg bot" id="luxuryTypingIndicator" style="display: none;">
            <div class="msg-avatar">🌿</div>
            <div class="chat-typing-indicator">
              <span class="typing-dot"></span>
              <span class="typing-dot"></span>
              <span class="typing-dot"></span>
            </div>
          </div>
        </div>

        <!-- Input Bar Footer -->
        <div class="luxury-chat-footer">
          <form class="chat-input-form" id="luxuryChatForm">
            <input 
              type="text" 
              class="chat-input-field" 
              id="luxuryChatInput" 
              placeholder="Ask about pricing, patios, pavers, decks..." 
              autocomplete="off"
              aria-label="Your question"
            />
            <button type="submit" class="chat-send-btn" id="luxuryChatSend" aria-label="Send message">
              <svg viewBox="0 0 24 24">
                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
              </svg>
            </button>
          </form>
          <div class="chat-quick-contact">
            <span>Direct Line:</span>
            <a href="tel:2069459777">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M6.62 10.79a15.053 15.053 0 006.59 6.59l2.2-2.2a1 1 0 011.01-.24c1.12.37 2.33.57 3.58.57a1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h3.5a1 1 0 011 1c0 1.25.2 2.45.57 3.57a1 1 0 01-.25 1.02l-2.2 2.2z"/></svg>
              (206) 945-9777
            </a>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(container);
    initChatbotEvents();
  }

  // Event Listeners & Interactive Logic
  function initChatbotEvents() {
    var trigger = document.getElementById('luxuryChatTrigger');
    var chatWindow = document.getElementById('luxuryChatWindow');
    var closeBtn = document.getElementById('luxuryChatClose');
    var resetBtn = document.getElementById('luxuryChatReset');
    var teaser = document.getElementById('luxuryChatTeaser');
    var teaserClose = document.getElementById('luxuryTeaserClose');
    var badge = document.getElementById('luxuryChatBadge');
    var chatForm = document.getElementById('luxuryChatForm');
    var chatInput = document.getElementById('luxuryChatInput');
    var chatBody = document.getElementById('luxuryChatBody');
    var typingIndicator = document.getElementById('luxuryTypingIndicator');

    // Auto-show teaser after 3.5 seconds if not already seen
    if (!sessionStorage.getItem('luxuryChatOpened')) {
      setTimeout(function () {
        if (teaser && !chatWindow.classList.contains('is-open')) {
          teaser.classList.remove('is-hidden');
        }
      }, 3500);
    }

    // Toggle Chat Window
    function toggleChat(forceState) {
      var isOpen = forceState !== undefined ? forceState : !chatWindow.classList.contains('is-open');
      if (isOpen) {
        chatWindow.classList.add('is-open');
        trigger.classList.add('is-active');
        trigger.setAttribute('aria-expanded', 'true');
        if (badge) badge.style.display = 'none';
        if (teaser) teaser.classList.add('is-hidden');
        sessionStorage.setItem('luxuryChatOpened', 'true');
        setTimeout(function () { chatInput.focus(); }, 250);
      } else {
        chatWindow.classList.remove('is-open');
        trigger.classList.remove('is-active');
        trigger.setAttribute('aria-expanded', 'false');
      }
    }

    trigger.addEventListener('click', function () {
      toggleChat();
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        toggleChat(false);
      });
    }

    if (teaser) {
      teaser.addEventListener('click', function (e) {
        if (e.target !== teaserClose) {
          toggleChat(true);
        }
      });
    }

    if (teaserClose) {
      teaserClose.addEventListener('click', function (e) {
        e.stopPropagation();
        teaser.classList.add('is-hidden');
      });
    }

    // Close on Escape Key
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && chatWindow.classList.contains('is-open')) {
        toggleChat(false);
      }
    });

    // Reset Chat
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        // Clear all user messages and keep only initial greeting
        var messages = chatBody.querySelectorAll('.chat-msg');
        for (var i = 1; i < messages.length; i++) {
          if (messages[i].id !== 'luxuryTypingIndicator') {
            messages[i].remove();
          }
        }
      });
    }

    // Handle Form Submit
    chatForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var query = chatInput.value.trim();
      if (!query) return;

      appendUserMessage(query);
      chatInput.value = '';
      chatInput.focus();

      // Show typing and reply
      simulateBotReply(query);
    });

    // Handle Suggestion Chip Clicks (delegated)
    chatBody.addEventListener('click', function (e) {
      var chip = e.target.closest('.chat-chip');
      if (chip) {
        var query = chip.getAttribute('data-query') || chip.textContent.trim();
        appendUserMessage(query);
        simulateBotReply(query);
      }
    });

    // Append User Message Bubble
    function appendUserMessage(text) {
      var userMsg = document.createElement('div');
      userMsg.className = 'chat-msg user';
      userMsg.innerHTML = `
        <div class="msg-avatar">👤</div>
        <div class="msg-content">
          <p>${escapeHTML(text)}</p>
          <span class="msg-time">${getTimeString()}</span>
        </div>
      `;
      chatBody.insertBefore(userMsg, typingIndicator);
      scrollToBottom();
    }

    // Append Bot Message Bubble
    function appendBotMessage(htmlContent, chips) {
      var botMsg = document.createElement('div');
      botMsg.className = 'chat-msg bot';
      
      var chipsHTML = '';
      if (chips && chips.length > 0) {
        chipsHTML = '<div class="chat-suggestions-wrap">';
        chips.forEach(function (c) {
          chipsHTML += `<button type="button" class="chat-chip" data-query="${escapeHTML(c)}">${escapeHTML(c)}</button>`;
        });
        chipsHTML += '</div>';
      }

      botMsg.innerHTML = `
        <div class="msg-avatar">🌿</div>
        <div class="msg-content">
          ${htmlContent}
          ${chipsHTML}
          <span class="msg-time">${getTimeString()}</span>
        </div>
      `;

      chatBody.insertBefore(botMsg, typingIndicator);
      scrollToBottom();
    }

    // Match Query and Simulate Reply
    function simulateBotReply(query) {
      typingIndicator.style.display = 'flex';
      scrollToBottom();

      var match = findBestMatch(query);
      var delay = Math.floor(Math.random() * 300) + 450; // realistic typing pause

      setTimeout(function () {
        typingIndicator.style.display = 'none';
        appendBotMessage(match.response, match.chips);
      }, delay);
    }

    function findBestMatch(userQuery) {
      var q = userQuery.toLowerCase();

      // Check for direct phone intent
      if (q.includes('call') || q.includes('phone') || q.includes('number')) {
        return {
          response: `
            <p>You can call our direct office line immediately at <a href="tel:2069459777"><strong>(206) 945-9777</strong></a>.</p>
            <p>Our office hours are <strong>Monday – Saturday: 7:00 AM – 6:00 PM</strong>. We can discuss your project and schedule an on-site visit.</p>
          `,
          chips: ['Book Free Consultation', 'Estimate Project Cost', 'Core Services']
        };
      }

      // Check match against knowledge base
      for (var i = 0; i < BOT_KNOWLEDGE.length; i++) {
        var item = BOT_KNOWLEDGE[i];
        for (var k = 0; k < item.keywords.length; k++) {
          if (q.includes(item.keywords[k])) {
            return item;
          }
        }
      }

      // Fallback
      return {
        response: DEFAULT_RESPONSE,
        chips: DEFAULT_CHIPS
      };
    }

    function scrollToBottom() {
      setTimeout(function () {
        chatBody.scrollTop = chatBody.scrollHeight;
      }, 50);
    }

    function getTimeString() {
      var now = new Date();
      var hours = now.getHours();
      var minutes = now.getMinutes();
      var ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12;
      minutes = minutes < 10 ? '0' + minutes : minutes;
      return hours + ':' + minutes + ' ' + ampm;
    }

    function escapeHTML(str) {
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }
  }

  // Initialize once DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectChatbotDOM);
  } else {
    injectChatbotDOM();
  }
})();
