/**
 * Luxury Landscape Designs Theme JavaScript
 *
 * @package Luxury_Landscape_Designs
 */

document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  // 1. Sticky Header with Scroll Detection
  var siteHeader = document.getElementById('masthead');
  if (siteHeader) {
    var checkScroll = function () {
      if (window.scrollY > 45) {
        siteHeader.classList.add('is-sticky');
      } else {
        siteHeader.classList.remove('is-sticky');
      }
    };
    window.addEventListener('scroll', checkScroll, { passive: true });
    checkScroll();
  }

  // 2. Mobile Navigation Toggle
  var mobileToggle = document.getElementById('mobile-menu-toggle');
  var mobileDrawer = document.getElementById('mobile-navigation');

  if (mobileToggle && mobileDrawer) {
    mobileToggle.addEventListener('click', function () {
      var isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
      mobileToggle.setAttribute('aria-expanded', !isExpanded);
      mobileDrawer.setAttribute('aria-hidden', isExpanded);
      mobileToggle.classList.toggle('is-active');
      mobileDrawer.classList.toggle('is-open');
      document.body.style.overflow = !isExpanded ? 'hidden' : '';
    });

    var mobileLinks = mobileDrawer.querySelectorAll('a');
    mobileLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        mobileToggle.setAttribute('aria-expanded', 'false');
        mobileDrawer.setAttribute('aria-hidden', 'true');
        mobileToggle.classList.remove('is-active');
        mobileDrawer.classList.remove('is-open');
        document.body.style.overflow = '';
      });
    });
  }

  // 3. Stats Counter Animation (IntersectionObserver)
  var statNumbers = document.querySelectorAll('.stat-number');
  if (statNumbers.length > 0 && 'IntersectionObserver' in window) {
    var statObserver = new IntersectionObserver(
      function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var el = entry.target;
            var target = parseInt(el.getAttribute('data-target'), 10);
            if (!isNaN(target)) {
              var count = 0;
              var speed = Math.max(16, Math.floor(1400 / target));
              var step = Math.max(1, Math.ceil(target / 45));
              var timer = setInterval(function () {
                count += step;
                if (count >= target) {
                  el.textContent = target;
                  clearInterval(timer);
                } else {
                  el.textContent = count;
                }
              }, speed);
            }
            obs.unobserve(el);
          }
        });
      },
      { threshold: 0.3 }
    );

    statNumbers.forEach(function (stat) {
      statObserver.observe(stat);
    });
  }

  // 4. Project Category Filtering
  var filterButtons = document.querySelectorAll('.filter-btn');
  var projectItems = document.querySelectorAll('#projects-gallery-grid .project-item');

  if (filterButtons.length > 0 && projectItems.length > 0) {
    filterButtons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        filterButtons.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');

        var filterValue = btn.getAttribute('data-filter');

        projectItems.forEach(function (item) {
          var itemCategory = item.getAttribute('data-category');
          if (filterValue === 'all' || itemCategory === filterValue) {
            item.classList.remove('is-hidden');
            item.style.animation = 'fadeInUp 0.5s ease forwards';
          } else {
            item.classList.add('is-hidden');
          }
        });
      });
    });
  }

  // 5. Contact Form AJAX Submission
  var contactForm = document.getElementById('earthly-contact-form');
  var formResponse = document.getElementById('contact-form-response');

  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();

      var nameInput = document.getElementById('contact-name');
      var emailInput = document.getElementById('contact-email');
      var phoneInput = document.getElementById('contact-phone');
      var serviceInput = document.getElementById('contact-service');
      var messageInput = document.getElementById('contact-message');
      var submitBtn = document.getElementById('contact-submit-btn');

      var hasError = false;

      [nameInput, emailInput, phoneInput].forEach(function (input) {
        if (!input) return;
        var err = input.parentElement.querySelector('.field-error');
        if (!input.value.trim()) {
          if (err) err.style.display = 'block';
          input.style.borderColor = '#e63946';
          hasError = true;
        } else {
          if (err) err.style.display = 'none';
          input.style.borderColor = '';
        }
      });

      if (emailInput && emailInput.value.trim() && !/\S+@\S+\.\S+/.test(emailInput.value.trim())) {
        var emailErr = emailInput.parentElement.querySelector('.field-error');
        if (emailErr) {
          emailErr.textContent = 'Please enter a valid email address.';
          emailErr.style.display = 'block';
        }
        emailInput.style.borderColor = '#e63946';
        hasError = true;
      }

      // Clear field errors on user input
      [nameInput, emailInput, phoneInput].forEach(function (input) {
        if (!input) return;
        input.addEventListener('input', function () {
          var err = input.parentElement.querySelector('.field-error');
          if (err) err.style.display = 'none';
          input.style.borderColor = '';
        });
      });

      if (hasError) {
        if (formResponse) {
          formResponse.style.display = 'block';
          formResponse.className = 'form-alert alert-error';
          formResponse.textContent = 'Please complete all required fields highlighted in red.';
          formResponse.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        return;
      }

      var formData = new FormData();
      formData.append('action', 'earthly_contact_form');
      formData.append('nonce', typeof earthlyData !== 'undefined' ? earthlyData.nonce : '');
      formData.append('name', nameInput.value.trim());
      formData.append('email', emailInput.value.trim());
      formData.append('phone', phoneInput.value.trim());
      formData.append('service', serviceInput ? serviceInput.value : '');
      formData.append('message', messageInput ? messageInput.value.trim() : '');

      submitBtn.disabled = true;
      var btnText = submitBtn.querySelector('.btn-text');
      var btnSpinner = submitBtn.querySelector('.btn-spinner');
      if (btnText) btnText.style.opacity = '0.5';
      if (btnSpinner) btnSpinner.style.display = 'inline';

      var targetUrl = (typeof earthlyData !== 'undefined' && earthlyData.ajaxUrl) ? earthlyData.ajaxUrl : '/api/contact';

      fetch(targetUrl, {
        method: 'POST',
        body: formData,
      })
        .then(function (res) {
          if (!res.ok) throw new Error('Network response was not ok');
          return res.json();
        })
        .then(function (data) {
          submitBtn.disabled = false;
          if (btnText) btnText.style.opacity = '1';
          if (btnSpinner) btnSpinner.style.display = 'none';

          if (formResponse) {
            formResponse.style.display = 'block';
            formResponse.className = 'form-alert alert-success';
            formResponse.textContent = (data.data && data.data.message) || 'Thank you! Your consultation request has been received. Our team will contact you shortly.';
            formResponse.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            contactForm.reset();
          }
        })
        .catch(function () {
          // Static fallback: show instant confirmation for static environments
          submitBtn.disabled = false;
          if (btnText) btnText.style.opacity = '1';
          if (btnSpinner) btnSpinner.style.display = 'none';

          if (formResponse) {
            formResponse.style.display = 'block';
            formResponse.className = 'form-alert alert-success';
            var clientName = nameInput.value.trim() || 'Valued Client';
            var clientService = (serviceInput && serviceInput.value) ? serviceInput.value : 'Landscape Design';
            formResponse.textContent = 'Thank you, ' + clientName + '! Your consultation request for "' + clientService + '" has been received. Our team will contact you at (206) 945-9777 or luxurylandscape16@gmail.com shortly.';
            formResponse.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            contactForm.reset();
          }
        });
    });
  }

  // 6. Projects Lightbox Modal
  var lightbox = document.getElementById('project-lightbox');
  var lightboxImg = document.getElementById('lightbox-img');
  var lightboxClose = document.querySelector('.lightbox-close');

  if (lightbox && lightboxImg) {
    document.querySelectorAll('.btn-lightbox').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var src = btn.getAttribute('data-src');
        if (src) {
          lightboxImg.src = src;
          lightbox.classList.add('is-active');
          lightbox.setAttribute('aria-hidden', 'false');
        }
      });
    });

    if (lightboxClose) {
      lightboxClose.addEventListener('click', function () {
        lightbox.classList.remove('is-active');
        lightbox.setAttribute('aria-hidden', 'true');
      });
    }

    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox) {
        lightbox.classList.remove('is-active');
        lightbox.setAttribute('aria-hidden', 'true');
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && lightbox.classList.contains('is-active')) {
        lightbox.classList.remove('is-active');
        lightbox.setAttribute('aria-hidden', 'true');
      }
    });
  }

  // 7. Interactive FAQ Accordion
  var faqQuestions = document.querySelectorAll('.faq-question');
  if (faqQuestions.length > 0) {
    faqQuestions.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var item = btn.closest('.faq-item');
        var isOpen = item.classList.contains('is-open');

        // Optional: close other open items for clean single accordion
        document.querySelectorAll('.faq-item.is-open').forEach(function (otherItem) {
          if (otherItem !== item) {
            otherItem.classList.remove('is-open');
          }
        });

        item.classList.toggle('is-open', !isOpen);
      });
    });
  }
});
