import http.server
import socketserver
import os
import json
import urllib.parse
import re

PORT = 8000
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

class LuxuryLandscapeHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        # Route clean paths to preview HTML pages
        routes = {
            '/home': '/index.html',
            '/about': '/about.html',
            '/about/': '/about.html',
            '/services': '/services.html',
            '/services/': '/services.html',
            '/projects': '/projects.html',
            '/projects/': '/projects.html',
            '/contact': '/contact.html',
            '/contact/': '/contact.html',
        }
        if parsed.path in routes:
            self.send_response(302)
            self.send_header('Location', routes[parsed.path])
            self.end_headers()
            return
        
        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in ['/api/contact', '/wp-admin/admin-ajax.php']:
            content_length = int(self.headers.get('Content-Length', 0))
            raw_data = self.rfile.read(content_length)
            
            # Extract fields from multipart or urlencoded
            text_data = raw_data.decode('utf-8', errors='ignore')
            
            name = "Valued Client"
            email = "luxurylandscape16@gmail.com"
            phone = "(206) 945 9777"
            service = "Landscape Design"

            # Parse multipart form fields
            name_match = re.search(r'name="name"[^\r\n]*\r?\n\r?\n([^\r\n]+)', text_data)
            if name_match: name = name_match.group(1).strip()

            email_match = re.search(r'name="email"[^\r\n]*\r?\n\r?\n([^\r\n]+)', text_data)
            if email_match: email = email_match.group(1).strip()

            phone_match = re.search(r'name="phone"[^\r\n]*\r?\n\r?\n([^\r\n]+)', text_data)
            if phone_match: phone = phone_match.group(1).strip()

            service_match = re.search(r'name="service"[^\r\n]*\r?\n\r?\n([^\r\n]+)', text_data)
            if service_match: service = service_match.group(1).strip()

            print(f"\n[NEW INQUIRY RECEIVED]")
            print(f"Name: {name}")
            print(f"Email: {email}")
            print(f"Phone: {phone}")
            print(f"Service: {service}")
            print(f"Destination: luxurylandscape16@gmail.com / (206) 945 9777\n", flush=True)

            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            response = {
                "success": True,
                "data": {
                    "message": f"Thank you, {name}! Your consultation request for '{service}' has been received. Our team will contact you at {phone} or {email} within 24 hours."
                }
            }
            self.wfile.write(json.dumps(response).encode('utf-8'))
            return

        self.send_error(404, "Endpoint not found")

def run():
    global PORT
    http.server.ThreadingHTTPServer.allow_reuse_address = True
    while True:
        try:
            with http.server.ThreadingHTTPServer(("0.0.0.0", PORT), LuxuryLandscapeHandler) as httpd:
                print(f"Luxury Landscape Designs server online at: http://localhost:{PORT}", flush=True)
                print(f"Direct Preview: http://localhost:{PORT}/index.html", flush=True)
                httpd.serve_forever()
        except OSError:
            PORT += 1

if __name__ == '__main__':
    run()
